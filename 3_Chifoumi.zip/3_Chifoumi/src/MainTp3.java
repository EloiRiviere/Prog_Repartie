package src;

import java.util.Scanner;

public class MainTp3 extends Thread
{
	// objet pour le synchronize
	static Object o = new Object();
	//nombre de victoires de chaque joueur
	static int nombre_victoires_j1 = 0, nombre_victoires_j2 = 0;
	//nom du joueur
	String nom;
	// choix du joueur
	int choix;

	//cadenas pour synchroniser les threads
	static int cadenas = 0;

	public MainTp3()
	{

	}

	public int getChoix()
	{
		return choix;
	}

	public String getNom()
	{
		return nom;
	}

	//code exécuté par les threads
	public void run()
	{
		Scanner sc = new Scanner(System.in);
		//synchronisation des threads
		synchronized(o)
		{
			// premier tour, demande du nom du joueur et de son choix
			this.setNom(sc);
			this.choisir(sc);
			// on incrémente le compteur
			cadenas++;
			// on donne la main au thread principal
			o.notifyAll();

			// boucle infinie tant que le thread principal ne tue pas ce thread
			if(cadenas != 2)
			{
				// on attend que le thread principal ait fini de jouer
				try
				{
					o.wait();
				}
				catch (InterruptedException e)
				{
					System.out.println("Interrupted exception");
				}
			}
		}

		while(true)
		{
			synchronized(o)
			{
				if(cadenas < 2)
				{
					this.choisir(sc);
					cadenas ++;
					o.notifyAll();
					try
					{
						o.wait();
					}
					catch (InterruptedException e)
					{
						System.out.println("Interrupted exception");
					}
				}
			}

		}
	}

	public void setNom(Scanner sc)
	{
		System.out.print("Rentre ton nom: ");
		nom = sc.nextLine();
	}

	public void choisir(Scanner sc)
	{
		System.out.print("\n" + nom + ", rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): ");
		choix = Integer.parseInt(sc.nextLine());
	}

	public static void main(String args[])
	{
		MainTp3 joueur1 = new MainTp3();
		MainTp3 joueur2 = new MainTp3();
		joueur1.start();
		joueur2.start();
		int i;
		for(i=0;i<2;i++)
		{
			synchronized (o)
			{
				try
				{
					//on s'endort (laisse les threads choisir nom et choix)
					o.wait();

				}
				catch (InterruptedException e)
				{
					System.out.println("Exception wait");
				}
			}
		}

		// traitement du jeu
		while(nombre_victoires_j1 < 3 && nombre_victoires_j2 < 3)
		{
			System.out.println(joueur1.getNom() + " joue " + joueur1.getChoix() + " et " + joueur2.getNom() + " joue " + joueur2.getChoix());

			if(joueur1.getChoix() == joueur2.getChoix())
			{
				System.out.println("Match nul.");
			}
			else if(joueur1.getChoix() == 0)
			{
				if(joueur2.getChoix()== 1)
				{
					nombre_victoires_j2 ++;
					System.out.println(joueur2.getNom() + "a gagné ! " + nombre_victoires_j1 + " points contre " + nombre_victoires_j2 + "points.");
				}
				else if(joueur2.getChoix() == 2)
				{
					nombre_victoires_j1 ++;
					System.out.println(joueur1.getNom() + "a gagné ! " + nombre_victoires_j1 + " points contre " + nombre_victoires_j2 + "points.");
				}
			}
			else if(joueur1.getChoix() == 1)
			{
				if(joueur2.getChoix()== 0)
				{
					nombre_victoires_j1 ++;
					System.out.println(joueur1.getNom() + "a gagné ! " + nombre_victoires_j1 + " points contre " + nombre_victoires_j2 + "points.");
				}
				else if(joueur2.getChoix() == 2)
				{
					nombre_victoires_j2 ++;
					System.out.println(joueur2.getNom() + "a gagné ! " + nombre_victoires_j1 + " points contre " + nombre_victoires_j2 + "points.");
				}
			}
			else
			{
				if(joueur2.getChoix()== 0)
				{
					nombre_victoires_j2 ++;
					System.out.println(joueur2.getNom() + "a gagné ! " + nombre_victoires_j1 + " points contre " + nombre_victoires_j2 + "points.");
				}
				else if(joueur2.getChoix() == 1)
				{
					nombre_victoires_j1 ++;
					System.out.println(joueur1.getNom() + "a gagné ! " + nombre_victoires_j1 + " points contre " + nombre_victoires_j2 + "points.");
				}
			}

			synchronized(o)
			{
				//reset le cadenas
				cadenas = 0;
				//réveille les threads
				o.notifyAll();
				try
				{
					//s'endort
					o.wait();
					o.wait();
				}
				catch (InterruptedException e)
				{
					System.out.println("Exception wait");
				}
			}
		}
		if(nombre_victoires_j1 == 3){System.out.println(joueur1.getNom() + " a gagné !");}
		else{System.out.println(joueur2.getNom() + " a gagné !");}
		//on tue les threads
		joueur1.interrupt();
		joueur2.interrupt();
	}
}

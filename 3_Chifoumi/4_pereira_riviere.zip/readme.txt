salome.pereira@etu.uca.fr
eloi.riviere@etu.uca.fr

Exemple d'exécution:

bash > java tp3.MainTp3

Rentre ton nom: joueur1
joueur1, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 0
Rentre ton nom: joueur2
joueur2, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 1

joueur2 joue 1 et joueur1 joue 0
joueur2 a gagné ! 1 points contre 0 points.


joueur1, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 1
joueur2, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 0

joueur2 joue 0 et joueur1 joue 1
joueur1 a gagné ! 1 points contre 1 points.



joueur1, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 0
joueur2, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 1

joueur2 joue 1 et joueur1 joue 0
joueur2 a gagné ! 2 points contre 1 points.


joueur1, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 0
joueur2, rentre 0 (pierre), 1 (feuille) ou 2 (ciseaux): 1

joueur2 joue 1 et joueur1 joue 0
joueur2 a gagné ! 3 points contre 1 points.


joueur2 a gagné !
Thread joueur 2 interrompu.
Thread joueur 1 interrompu.
